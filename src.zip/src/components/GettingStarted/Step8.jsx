// Step8.jsx

import React, { useState } from 'react';
import PropTypes from 'prop-types';

const Step8 = ({ previousStep, formData, nextStep, handleSubmit }) => {
  const [isChecked, setIsChecked] = useState(false);

  const handleCheckboxChange = (event) => {
    setIsChecked(event.target.checked);
  };

  const onSubmit = () => {
    if (!isChecked) {
      alert('You must agree to the Privacy Policy and Terms of Service to proceed.');
      return;
    }
    handleSubmit(formData); // Call the handleSubmit function passed from props
    nextStep();
  };

  return (
    <div className="step8-container">
      <h2 className="step8-title">Privacy Policy & Terms of Service</h2>
      <div className="privacy-policy">
        <p><strong>1. Information We Collect</strong></p>
        <ul>
          <li>Personal Information: Name, email, child’s preferences, and schedule.</li>
          <li>Usage Data: App interactions and device details.</li>
          <li>Permissions: Location (for context-aware suggestions) and Camera (for vocabulary input).</li>
        </ul>
        <p><strong>2. How We Use Your Information</strong></p>
        <ul>
          <li>To personalize your child’s experience.</li>
          <li>To improve app functionality and provide support.</li>
        </ul>
        <p><strong>3. Sharing Your Information</strong></p>
        <ul>
          <li>We never sell your data.</li>
          <li>Data is shared only with trusted service providers or when required by law.</li>
        </ul>
        <p><strong>4. Your Rights</strong></p>
        <ul>
          <li>Access, update, or delete your data anytime.</li>
          <li>Withdraw permissions (some features may not work without access).</li>
        </ul>

        <h3>Terms of Service</h3>
        <p><strong>1. App Usage</strong></p>
        <ul>
          <li>Use the app as intended.</li>
          <li>Do not misuse or compromise its security.</li>
        </ul>
        <p><strong>2. Limitation of Liability</strong></p>
        <ul>
          <li>Expressly is not responsible for indirect damages caused by app usage.</li>
        </ul>
      </div>

      <div className="agreement-section">
        <input 
          type="checkbox" 
          id="agree-terms" 
          checked={isChecked} 
          onChange={handleCheckboxChange} 
        />
        <label className="agree-terms" htmlFor="agree-terms">
          I agree to the Privacy Policy and Terms of Service.
        </label>
      </div>
      <div className="button-container">
        <button type="button" className="button-fill" onClick={previousStep}>
          Back
        </button>
        <button type="button" className="button-fill" onClick={onSubmit}>
          Finish
        </button>
      </div>
    </div>
  );
};

Step8.propTypes = {
  previousStep: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
};

export default Step8;