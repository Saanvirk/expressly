import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Step9 = ({ setAuthState }) => {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      setAuthState('logined'); // Set the auth state to logged in
      navigate('/main'); // Redirect to the main page
    }, 1000);

    return () => clearTimeout(timer); // Clean up the timeout on unmount
  }, [navigate, setAuthState]);

  return (
    <div>
      <img src="Material_4.png" alt="Completion Graphic" style={{ width: '300px' }} />
      <h1 className="step1-heading">You Are All SET!!</h1>
      <p className="step9-text">You’re ready to explore Expressly.</p>
    </div>
  );
};

export default Step9;