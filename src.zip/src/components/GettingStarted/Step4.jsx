import React from 'react';

const Step4 = ({ previousStep, nextStep, formData, setFormData }) => {
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div>
      <h2 className="step-title">Tell us about your child</h2>
      <p className="step3-text">
        (We’ll use this to personalize their communication experience.)
      </p>
      <form className="step3-form">
        <label htmlFor="childInterest">What are your child's interests?</label>
        <input
          type="text"
          id="childInterest"
          name="childInterest"
          required
          onChange={handleChange}
          value={formData.childInterest || ''}
        />

        <label htmlFor="favoriteMeals">
          What are your child’s favorite meal options?
        </label>
        <input
          type="text"
          id="favoriteMeals"
          name="favoriteMeals"
          required
          onChange={handleChange}
          value={formData.favoriteMeals || ''}
        />

        <label htmlFor="childHobbies">What are your child’s hobbies?</label>
        <input
          type="text"
          id="childHobbies"
          name="childHobbies"
          required
          onChange={handleChange}
          value={formData.childHobbies || ''}
        />

        <label htmlFor="interactingPeople">
          Who are the people your child interacts with most often?
        </label>
        <textarea
          id="interactingPeople"
          name="interactingPeople"
          rows="4"
          cols="50"
          required
          onChange={handleChange}
          value={formData.interactingPeople || ''}
        />
      </form>
      <br />
      <button type="button" className="button-fill" onClick={previousStep}>
        Back
      </button>
      <button type="button" className="button-fill" onClick={() => {
        console.log(formData);
        nextStep();
      }}>
        Next
      </button>
    </div>
  );
};

export default Step4;