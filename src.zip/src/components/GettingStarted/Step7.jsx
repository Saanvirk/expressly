import React, { useState } from 'react';

const Step7 = ({ previousStep, nextStep }) => {
  const [locationPermission, setLocationPermission] = useState(false);
  const [cameraPermission, setCameraPermission] = useState(false);

  const handleLocationToggle = async (event) => {
    if (event.target.checked) {
      try {
        const permission = await navigator.permissions.query({ name: 'geolocation' });
        if (permission.state === 'granted' || permission.state === 'prompt') {
          navigator.geolocation.getCurrentPosition(
            () => setLocationPermission(true),
            () => setLocationPermission(false)
          );
        } else {
          alert('Location permission denied');
          setLocationPermission(false);
        }
      } catch (error) {
        console.error('Error requesting location permission:', error);
        setLocationPermission(false);
      }
    } else {
      setLocationPermission(false);
    }
  };

  const handleCameraToggle = async (event) => {
    if (event.target.checked) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (stream) {
          setCameraPermission(true);
          stream.getTracks().forEach((track) => track.stop()); // Stop the camera after getting permission
        }
      } catch (error) {
        console.error('Error requesting camera permission:', error);
        alert('Camera permission denied');
        setCameraPermission(false);
      }
    } else {
      setCameraPermission(false);
    }
  };

  const handleSubmit = () => {
    alert('Permissions Saved!');
    // Redirect to the main page logic here
  };

  return (
    <div className="step7-container">
      <h2 className="step7-title">We need permissions to provide the best experience.</h2>
      
      <div className="permission-toggle">
        <div className="permission-item">
          <label htmlFor="location-permission" className="permission-label">
            <span role="img" aria-label="location">📍</span> Location
          </label>
          <input 
            type="checkbox" 
            id="location-permission" 
            name="location-permission" 
            onChange={handleLocationToggle} 
            checked={locationPermission}
          />
          <p className="permission-description">To suggest words based on where your child is.</p>
        </div>
        
        <div className="permission-item">
          <label htmlFor="camera-permission" className="permission-label">
            <span role="img" aria-label="camera">📷</span> Camera
          </label>
          <input 
            type="checkbox" 
            id="camera-permission" 
            name="camera-permission" 
            onChange={handleCameraToggle} 
            checked={cameraPermission}
          />
          <p className="permission-description">To analyze images and generate relevant vocabulary.</p>
        </div>
      </div>
      
      <div className="button-container">
        <button type="button" className="button-fill" onClick={previousStep}>
          Back
        </button>
        <button type="button" className="button-fill" onClick={nextStep}>
          Next
        </button>
      </div>
    </div>
  );
};

export default Step7;