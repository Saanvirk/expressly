import React from 'react';

const Step2 = ({ nextStep }) => {
  return (
    <div className="step2-container">
      <h2 className="step1-heading">
        How <span className="highlight">Expressly</span> Works?
      </h2>
      <div className="step2-content">
        <img
          src="Material_3.png" // Replace with the actual image path
          alt="How Expressly Works Illustration"
          className="step2-image"
        />
        <ul className="step2-list">
          <li>
            AI predicts <strong>six words</strong> based on <em>time</em>, <em>location</em>, and your <em>child's schedule</em>
          </li>
          <li>
            Select words to <strong>form sentences</strong> that grow dynamically
          </li>
          <li>
            Use <strong>text</strong> or <strong>image input</strong> for custom vocabulary
          </li>
        </ul>
        <button type="button" className="button-fill" onClick={nextStep}>
          Next
        </button>
      </div>
    </div>
  );
};

export default Step2;