import React, { useState } from 'react';

const Step6 = ({ previousStep, nextStep, formData, setFormData }) => {
  const [schedules, setSchedules] = useState(
    formData.schedules || [{ startTime: '', endTime: '', activity: '', location: '' }]
  );

  const handleAddSchedule = () => {
    setSchedules([
      ...schedules,
      { startTime: '', endTime: '', activity: '', location: '' },
    ]);
  };

  const handleRemoveSchedule = (index) => {
    const updatedSchedules = schedules.filter((_, i) => i !== index);
    setSchedules(updatedSchedules);
  };

  const handleScheduleChange = (index, field, value) => {
    const updatedSchedules = schedules.map((schedule, i) =>
      i === index ? { ...schedule, [field]: value } : schedule
    );
    setSchedules(updatedSchedules);
  };

  const handleNext = () => {
    setFormData({
      ...formData,
      schedules: schedules,
    });
    nextStep();
  };

  return (
    <div className="step5-container">
      <h2 className="step-title">Tell us about your child’s daily schedule</h2>
      <p className="step-subtitle">
        (We’ll use this to personalize their communication experience.)
      </p>

      <div className="schedule-list">
        {schedules.map((schedule, index) => (
          <div key={index} className="schedule-item">
            <div className="button-container">
              {index === schedules.length - 1 ? (
                <button type="button" className="button-add" onClick={handleAddSchedule}>
                  +
                </button>
              ) : (
                <button
                  type="button"
                  className="button-remove"
                  onClick={() => handleRemoveSchedule(index)}
                >
                  -
                </button>
              )}
            </div>
            <div className="input-fields">
              <input
                type="text"
                placeholder="Starting Time"
                value={schedule.startTime}
                onChange={(e) => handleScheduleChange(index, 'startTime', e.target.value)}
                className="input-field"
              />
              <input
                type="text"
                placeholder="Ending Time"
                value={schedule.endTime}
                onChange={(e) => handleScheduleChange(index, 'endTime', e.target.value)}
                className="input-field"
              />
              <input
                type="text"
                placeholder="Activity"
                value={schedule.activity}
                onChange={(e) => handleScheduleChange(index, 'activity', e.target.value)}
                className="input-field"
              />
              <input
                type="text"
                placeholder="Location"
                value={schedule.location}
                onChange={(e) => handleScheduleChange(index, 'location', e.target.value)}
                className="input-field"
              />
            </div>
          </div>
        ))}
      </div>

      <div className="step-buttons">
        <button type="button" className="button-fill" onClick={previousStep}>
          Back
        </button>
        <button type="button" className="button-fill" onClick={handleNext}>
          Next
        </button>
      </div>
    </div>
  );
};

export default Step6;