import React from 'react';

const Step1 = ({ nextStep }) => {
  return (
    <div>
      <img src="Material_2.png" alt="" style={{ width: '300px' }} />
      <h1 className="step1-heading">Your account has been created.</h1>
      <button type="button" className="button-fill" onClick={nextStep}>
        Let's get started!
      </button>
    </div>
  );
};

export default Step1;