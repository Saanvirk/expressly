import React, { useState, useEffect, useRef } from "react";

const Step5 = ({ previousStep, nextStep }) => {
  const [schedules, setSchedules] = useState([
    { startTime: "", endTime: "", activity: "", location: "" },
  ]);
  const addButtonRef = useRef(null);

  const handleAddSchedule = () => {
    if (schedules.length < 4) {
      setSchedules([
        ...schedules,
        { startTime: "", endTime: "", activity: "", location: "" },
      ]);
    }
  };

  const handleScheduleChange = (index, field, value) => {
    const updatedSchedules = schedules.map((schedule, i) =>
      i === index ? { ...schedule, [field]: value } : schedule
    );
    setSchedules(updatedSchedules);
  };

  // Animate cursor to "Add" button and trigger a click
  useEffect(() => {
    const simulateClick = () => {
      if (addButtonRef.current) {
        addButtonRef.current.classList.add("animated-cursor");
        setTimeout(() => {
          addButtonRef.current.click();
          addButtonRef.current.classList.remove("animated-cursor");
        }, 1000); // Time to animate cursor to button
      }
    };
    const interval = setInterval(simulateClick, 1000); // Repeat every 2 seconds
    return () => clearInterval(interval); // Cleanup interval
  }, []);

  return (
    <div className="step5-container">
      <h2 className="step-title">Tell us about your child’s daily schedule</h2>
      <p className="step-subtitle">
        (We’ll use this to personalize their communication experience.)
      </p>

      <div className="schedule-list">
        {schedules.map((schedule, index) => (
          <div
            key={index}
            className="schedule-item fade-in" // Add fade-in animation for new fields
          >
            <div className="button-container">
              {index === schedules.length - 1 && schedules.length < 5 && (
                <button
                  type="button"
                  ref={addButtonRef}
                  className="button-add"
                  onClick={handleAddSchedule}
                >
                  +
                </button>
              )}
            </div>
            <div className="input-fields">
              <input
                type="text"
                placeholder="Starting Time"
                value={schedule.startTime}
                onChange={(e) =>
                  handleScheduleChange(index, "startTime", e.target.value)
                }
                className="input-field"
              />
              <input
                type="text"
                placeholder="Ending Time"
                value={schedule.endTime}
                onChange={(e) =>
                  handleScheduleChange(index, "endTime", e.target.value)
                }
                className="input-field"
              />
              <input
                type="text"
                placeholder="Activity"
                value={schedule.activity}
                onChange={(e) =>
                  handleScheduleChange(index, "activity", e.target.value)
                }
                className="input-field"
              />
              <input
                type="text"
                placeholder="Location"
                value={schedule.location}
                onChange={(e) =>
                  handleScheduleChange(index, "location", e.target.value)
                }
                className="input-field"
              />
            </div>
          </div>
        ))}
      </div>

      <div className="step-buttons">
        <button type="button" className="button-fill" onClick={previousStep}>
          Back
        </button>
        <button type="button" className="button-fill" onClick={nextStep}>
          Next
        </button>
      </div>
    </div>
  );
};

export default Step5;