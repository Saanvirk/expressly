import React from 'react';

const Step3 = ({ previousStep, nextStep, formData, setFormData }) => {
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div>
      <h2 className="step-title">Tell us about your child</h2>
      <p className="step3-text">
        (We’ll use this to personalize their communication experience.)
      </p>
      <form className="step3-form">
        <label htmlFor="childName">Child's Name:</label>
        <input
          type="text"
          id="childName"
          name="childName"
          required
          onChange={handleChange}
          value={formData.childName || ''}
        />

        <label htmlFor="childAge">Child's Age:</label>
        <input
          type="number"
          id="childAge"
          name="childAge"
          required
          onChange={handleChange}
          value={formData.childAge || ''}
        />

        <label htmlFor="childDiagnosis">Child's Diagnosis:</label>
        <input
          type="text"
          id="childDiagnosis"
          name="childDiagnosis"
          required
          onChange={handleChange}
          value={formData.childDiagnosis || ''}
        />

        <label htmlFor="additionalPreference">
          Any additional preferences or notes?
        </label>
        <textarea
          id="additionalPreference"
          name="additionalPreference"
          rows="4"
          cols="50"
          required
          onChange={handleChange}
          value={formData.additionalPreference || ''}
        />
      </form>
      <br />
      <button type="button" className="button-fill" onClick={previousStep}>
        Back
      </button>
      <button
        type="button"
        className="button-fill"
        onClick={() => {
          console.log(formData);
          nextStep();
        }}
      >
        Next
      </button>
    </div>
  );
};

export default Step3;