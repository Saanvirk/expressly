import React from 'react';

const CommunicationContext = () => {
  return (
    <div className="page-container">
      <h1>Communication Context</h1>
      <p>This is the Communication Context page.</p>
    </div>
  );
};

export default CommunicationContext;