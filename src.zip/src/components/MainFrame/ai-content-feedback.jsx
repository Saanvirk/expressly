// AIContentFeedback.jsx

import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ref, set } from 'firebase/database';
import { auth } from '../../config/firebase-auth'; // Ensure database is exported from firebase-auth
import ReactMarkdown from 'react-markdown';
import '../../styles/AIContentFeedback.css';

const AIContentFeedback = () => {
  const navigate = useNavigate();
  const [messages, setMessages] = useState([
    { type: 'bot', content: 'Hello! I am here to help improve your child’s communication experience. Shall we begin?', typing: false }
  ]);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef(null);
  const [conversationData, setConversationData] = useState({});

  // Replace with your actual API keys and handle them securely
  const LEONARDO_API_KEY = '0857e985-7684-4e17-8241-384f75e2ebe0';
  const OPENAI_API_KEY = 'sk-KrJ8ttjJnAnBhLKtCc86719c13754cF3BdC2E4545b217d46';

  // Scroll to the bottom of the chat when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const goBack = () => navigate(-1);

  const handleSendMessage = async () => {
    const trimmedMessage = inputValue.trim();
    if (trimmedMessage) {
      // Add the user's message to the chat
      setMessages(prevMessages => [
        ...prevMessages,
        { type: 'user', content: trimmedMessage, typing: false },
      ]);

      setInputValue(''); // Clear the input

      // Check if the user requested a custom image
      const imageRequestMatch = trimmedMessage.match(/(generate a custom image about|i want to generate a custom image about)\s(.+)/i);
      if (imageRequestMatch) {
        const item = imageRequestMatch[2].trim();
        await generateImageFromLeonardo(item);
        return;
      }

      // Otherwise, call the OpenAI API for a text response
      await handleTextResponse(trimmedMessage);
    }
  };

  const handleTextResponse = async (userMessage) => {
    const chatHistory = messages.map(msg => `${msg.type === 'bot' ? 'Bot' : 'User'}: ${msg.content}`).join('\n');

    const fullPrompt = `You are an AI assistant designed to collect feedback from parents to improve their child's communication experience using our app. Guide the parent through a series of questions to gather detailed feedback. At the end, summarize the information collected.

Chat History:
${chatHistory}
User: ${userMessage}
Assistant:`;

    const apiUrl = 'https://www.jcapikey.com/v1/chat/completions';
    const data = {
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: fullPrompt }],
      temperature: 0.7,
    };

    // Add a typing indicator
    setMessages(prevMessages => [
      ...prevMessages,
      { type: 'bot', content: '', typing: true },
    ]);

    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${OPENAI_API_KEY}`,
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      const responseMessage = result.choices[0].message.content;

      // Remove the typing indicator and add the bot's response
      setMessages(prevMessages => {
        const updatedMessages = [...prevMessages];
        updatedMessages.pop(); // remove the typing indicator
        return [
          ...updatedMessages,
          { type: 'bot', content: responseMessage, typing: false },
        ];
      });

      // Extract useful data from the conversation
      collectConversationData(responseMessage);

    } catch (error) {
      console.error('Error:', error);

      // Remove the typing indicator and add an error message
      setMessages(prevMessages => {
        const updatedMessages = [...prevMessages];
        updatedMessages.pop(); // remove the typing indicator
        return [
          ...updatedMessages,
          { type: 'bot', content: 'Sorry, there was an error processing your request.', typing: false },
        ];
      });
    }
  };

  const collectConversationData = (botMessage) => {
    // Add logic to extract info from the conversation
    // Example:
    if (botMessage.toLowerCase().includes('name')) {
      setConversationData(prevData => ({ ...prevData, name: inputValue }));
    }
  };

  const generateImageFromLeonardo = async (promptItem) => {
    // Add a typing indicator
    setMessages(prev => [...prev, { type: 'bot', content: '', typing: true }]);

    const leonardoUrl = 'https://cloud.leonardo.ai/api/rest/v1/generations';
    const requestBody = {
      modelId: '6b645e3a-d64f-4341-a6d8-7a3690fbf042',
      contrast: 3.5,
      prompt: `AAC Icon ${promptItem}`,
      num_images: 1,
      width: 512,
      height: 512,
      alchemy: true,
      styleUUID: '111dc692-d470-4eec-b791-3475abac4c46',
      enhancePrompt: false
    };

    try {
      const response = await fetch(leonardoUrl, {
        method: 'POST',
        headers: {
          accept: 'application/json',
          'content-type': 'application/json',
          'Authorization': `Bearer ${LEONARDO_API_KEY}`
        },
        body: JSON.stringify(requestBody)
      });

      const res = await response.json();
      console.log('Leonardo response:', res);

      // Remove the typing indicator
      setMessages(prevMessages => {
        const updatedMessages = [...prevMessages];
        updatedMessages.pop(); // Remove the typing message
        return updatedMessages;
      });

      if (res.generations && res.generations.length > 0 && res.generations[0].generated_images && res.generations[0].generated_images.length > 0) {
        const imageUrl = res.generations[0].generated_images[0].url;
        // Display the image to the user
        setMessages(prevMessages => [
          ...prevMessages,
          { type: 'bot', content: `Here is your custom image about ${promptItem}:`, typing: false },
          { type: 'bot', content: `![](${imageUrl})`, typing: false } // Markdown image syntax
        ]);
      } else {
        setMessages(prevMessages => [
          ...prevMessages,
          { type: 'bot', content: 'Please wait for the image generation', typing: false },
        ]);
      }

      if (res.sdGenerationJob && res.sdGenerationJob.generationId) {
        const generationId = res.sdGenerationJob.generationId;
        const imageUrl = `https://cloud.leonardo.ai/api/rest/v1/generations/${generationId}`;

        // Wait for 5 seconds before retrieving the image
        await new Promise(resolve => setTimeout(resolve, 20000));

        const imageResponse = await fetch(imageUrl, {
          method: 'GET',
          headers: {
            accept: 'application/json',
            'Authorization': `Bearer ${LEONARDO_API_KEY}`
          }
        });

        const imageResult = await imageResponse.json();
        console.log('Image result:', imageResult);
        if (imageResult && imageResult.generations_by_pk && imageResult.generations_by_pk.generated_images && imageResult.generations_by_pk.generated_images.length > 0) {
          const finalImageUrl = imageResult.generations_by_pk.generated_images[0].url;
            setMessages(prevMessages => [
            ...prevMessages,
            { type: 'bot', content: `Here is your custom image about ${promptItem}:`, typing: false },
            { type: 'bot', content: `![Custom Image](${finalImageUrl})`, typing: false }
            ]);
        } else {
          setMessages(prevMessages => [
            ...prevMessages,
            { type: 'bot', content: 'Sorry, I could not retrieve the generated image at this time.', typing: false },
          ]);
        }
      } else {
        setMessages(prevMessages => [
          ...prevMessages,
          { type: 'bot', content: 'Sorry, I could not generate an image at this time.', typing: false },
        ]);
      }

    } catch (error) {
      console.error('Error generating image:', error);
      // Remove the typing indicator and add an error message
      setMessages(prevMessages => {
        const updatedMessages = [...prevMessages];
        if (updatedMessages[updatedMessages.length - 1]?.typing) {
          updatedMessages.pop();
        }
        return [
          ...updatedMessages,
          { type: 'bot', content: 'Sorry, there was an error generating the image.', typing: false },
        ];
      });
    }
  };

  const updateFirebaseData = () => {
    const userId = auth.currentUser?.uid;
    if (userId) {
      const userRef = ref(database, 'users/' + userId + '/feedback');
      set(userRef, conversationData)
        .then(() => {
          console.log('Data saved successfully.');
        })
        .catch((error) => {
          console.error('Error saving data:', error);
        });
    } else {
      console.error('User is not authenticated.');
    }
  };

  useEffect(() => {
    // Check if the conversation has ended
    if (messages.length > 1 && messages[messages.length - 1].content.toLowerCase().includes('thank you for your feedback')) {
      updateFirebaseData();
    }
  }, [messages]);

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  return (
    <div className="container">
      <div className="left-panel">
        <button className="panel-button" onClick={goBack}>Back</button>
      </div>
      <div className="chat-container">
        <div className="chat-title">AI Content Feedback</div>
        <div className="messages">
          {messages.map((message, index) => (
            <div key={index} className={`message ${message.type}`}>
              {message.type === 'bot' && <img src="AI_Bot.png" alt="Bot Profile" />}
              <div className={`message-content ${message.typing ? 'typing' : ''}`}>
                <ReactMarkdown>{message.content}</ReactMarkdown>
              </div>
              {message.type === 'user' && <img src="profile_pic.png" alt="User Profile" />}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        <div className="input-area">
          <input
            type="text"
            value={inputValue}
            onChange={handleInputChange}
            placeholder="Type your message..."
            onKeyDown={(e) => { if (e.key === 'Enter') handleSendMessage(); }}
          />
          <button onClick={handleSendMessage}>
            <img src="send_arrow.png" alt="Send" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default AIContentFeedback;