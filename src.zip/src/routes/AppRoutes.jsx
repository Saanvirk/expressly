import { Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from '../pages/LoginPage';
import RegisterPage from '../pages/RegisterPage';
import GettingStartedPage from '../pages/GettingStartedPage';
import MainPage from '../pages/MainPage';
import CommunicationContext from '../components/MainFrame/communication-context';
import SupportResources from '../components/MainFrame/support-resources';
import AIContentFeedback from '../components/MainFrame/ai-content-feedback';
import AICustomerService from '../components/MainFrame/ai-customer-service';

const AppRoutes = ({ authState, setAuthState }) => {
  return (
    <Routes>
      {/* Default route redirects to login if not logged in */}
      <Route path="/" element={<Navigate to={authState === 'logined' ? "/main" : "/login"} />} />

      {/* Login route */}
      <Route
        path="/login"
        element={
          authState === 'logined' ? (
            <Navigate to="/main" />
          ) : (
            <LoginPage setAuthState={setAuthState} />
          )
        }
      />

      {/* Getting Started route */}
      <Route
        path="/getting-started"
        element={
          authState === 'logined' ? (
            <Navigate to="/main" />
          ) : (
            <GettingStartedPage setAuthState={setAuthState} />
          )
        }
      />

      {/* Register route */}
      <Route
        path="/register"
        element={
          authState === 'logined' ? (
            <Navigate to="/main" />
          ) : (
            <RegisterPage setAuthState={setAuthState} />
          )
        }
      />

      {/* Main route, only accessible if logged in */}
      <Route
        path="/main/*"
        element={
          authState === 'logined' ? (
            <MainPage />
          ) : (
            <Navigate to="/login" />
          )
        }
      />

      {/* Communication Context route */}
      <Route
        path="/communication-context"
        element={
          authState === 'logined' ? (
            <CommunicationContext />
          ) : (
            <Navigate to="/login" />
          )
        }
      />

      {/* Support Resources route */}
      <Route
        path="/support-resources"
        element={
          authState === 'logined' ? (
            <SupportResources />
          ) : (
            <Navigate to="/login" />
          )
        }
      />

      {/* AI Content Feedback route */}
      <Route
        path="/ai-content-feedback"
        element={
          authState === 'logined' ? (
            <AIContentFeedback />
          ) : (
            <Navigate to="/login" />
          )
        }
      />

      {/* AI Customer Service route */}
      <Route
        path="/ai-customer-service"
        element={
          authState === 'logined' ? (
            <AICustomerService />
          ) : (
            <Navigate to="/login" />
          )
        }
      />
    </Routes>
  );
};

export default AppRoutes;
