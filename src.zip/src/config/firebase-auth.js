// firebase-auth.js

import app from './firebase-config';
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signInWithPopup, 
  GoogleAuthProvider 
} from 'firebase/auth';
import { getDatabase, ref, set, push, update, remove, onValue } from 'firebase/database';

const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

const db = getDatabase(app);

// Sign-up with Email/Password
export const signupWithEmail = async (email, password) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    return userCredential.user; // Return the user object
  } catch (error) {
    console.error("Error signing up with email:", error.message);
    throw error;
  }
};

// Sign-in with Email/Password
export const signInUserWithEmailAndPassword = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user; // Return the user object
  } catch (error) {
    console.error("Error signing in with email:", error.message);
    throw error;
  }
};

// Sign-up/Sign-in with Google
export const signupWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user; // Return the user object
  } catch (error) {
    console.error("Error signing up with Google:", error.message);
    throw error;
  }
};

export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user; // Return the user object
  } catch (error) {
    console.error("Error signing in with Google:", error.message);
    throw error;
  }
};

export { auth, db, googleProvider, ref, set, push, update, remove, onValue, getAuth };