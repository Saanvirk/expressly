// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCnmvPCgJexyZDTGbM7z8oEpOxJ8xl_I8Q",
  authDomain: "exprey-1e2c9.firebaseapp.com",
  databaseURL: "https://exprey-1e2c9-default-rtdb.asia-southeast1.firebasedatabase.app/",
  projectId: "exprey-1e2c9",
  storageBucket: "exprey-1e2c9.firebasestorage.app",
  messagingSenderId: "174130230769",
  appId: "1:174130230769:web:23f27fd7f1150070e40050"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app; // Export only the initialized app