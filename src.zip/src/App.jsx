import React, { useState, useEffect } from 'react';
import { BrowserRouter, useNavigate } from 'react-router-dom';
import AppRoutes from './routes/AppRoutes';
import './styles/base.css';
import './styles/SplashScreen.css';

const App = () => {
  const [isLoading, setIsLoading] = useState(true); // For splash screen
  const [authState, setAuthState] = useState('logouted'); // 'logouted', 'logined', 'registering'

  useEffect(() => {
    console.log('Setting loading state to false after 2 seconds');
    const timer = setTimeout(() => {
      setIsLoading(false);
      console.log('isLoading:', isLoading); // Debug log
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <BrowserRouter>
      {isLoading ? (
        <div className="splash-screen">
          <img
            src="Material_1.png"
            alt="Expressly Logo"
            className="splash-logo"
          />
          <h1 className="splash-title">Expressly</h1>
          <p className="splash-tagline">
            "Empowering non-verbal communication with AI."
          </p>
        </div>
      ) : (
        <AppRoutes authState={authState} setAuthState={setAuthState} />
      )}
    </BrowserRouter>
  );
};

export default App;