import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2'; // Import SweetAlert2
import { signupWithEmail, signupWithGoogle } from '../config/firebase-auth';
import '../styles/LoginPage.css';

const RegisterPage = ({ setAuthState }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleRegister = async () => {
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      Swal.fire({
        icon: 'error',
        title: 'Registration Failed',
        text: 'Passwords do not match.',
      });
      return;
    }

    try {
      const user = await signupWithEmail(email, password);
      console.log('User registered:', user);
      setAuthState('firsttime');
      navigate('/GettingStarted');
    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Registration Failed',
        text: error.message,
      });
    }
  };

  const handleGoogleSignup = async () => {
    try {
      const user = await signupWithGoogle();
      console.log('User signed in with Google:', user);
      setAuthState('firsttime');
      navigate('/getting-started');
    } catch (error) {
      setError(error.message);
      Swal.fire({
        icon: 'error',
        title: 'Google Sign-up Failed',
        text: error.message,
      });
    }
  };

  const handleLoginRedirect = () => {
    navigate('/login');
  };

  return (
    <div className="login-container">
      <div className="login-header">
        <img
          src="Material_2.png" // Replace with your image path
          alt="Logo"
          className="login-logo"
        />
        <h1 className="login-title">Communicate <span className="highlight">Expressly</span></h1>
      </div>
      <div className="login-form-container">
        <div className="login-tabs">
          <button className="tab-button" onClick={handleLoginRedirect}>
            Login
          </button>
          <button className="tab-button active">Register</button>
        </div>
        {error && <p className="error-message">{error}</p>}
        <form className="login-form" onSubmit={(e) => e.preventDefault()}>
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            placeholder="Enter your Email"
            className="input-field"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            placeholder="Enter your Password"
            className="input-field"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <label htmlFor="confirm-password">Confirm Password</label>
          <input
            type="password"
            id="confirm-password"
            placeholder="Re-enter your Password"
            className="input-field"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
          <div className="form-footer">
            <button type="button" className="login-button" onClick={handleRegister}>
              Register
            </button>
          </div>
        </form>
        <div className="google-signin-container">
          <button className="google-signin-button" onClick={handleGoogleSignup}>
            <img
              src="google-icon.svg" // Replace with Google icon path
              alt="Google Icon"
              className="google-icon"
            />
            Sign up with Google
          </button>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;