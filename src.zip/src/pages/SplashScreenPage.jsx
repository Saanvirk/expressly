import React from 'react';
import '../styles/SplashScreen.css';

const SplashScreen = () => {
  return (
    <div className="splash-screen">
      <img
        src="Material_1.png"
        alt="Expressly Logo"
        className="splash-logo"
      />
      <h1 className="splash-title">Expressly</h1>
      <p className="splash-tagline">
        "Empowering non-verbal communication with AI."
      </p>
    </div>
  );
};

export default SplashScreen;