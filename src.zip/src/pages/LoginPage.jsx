import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2'; // Import SweetAlert2
import { signInUserWithEmailAndPassword, signInWithGoogle } from '../config/firebase-auth'; // Import Firebase auth functions
import '../styles/LoginPage.css';

const LoginPage = ({ setAuthState }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    setError('');
    try {
      const user = await signInUserWithEmailAndPassword(email, password);
      console.log('User logged in:', user);
      setAuthState('logined');
      navigate('/main');
    } catch (error) {
      console.error('Login error:', error.message);
      // setError(error.message);
      Swal.fire({
        icon: 'error',
        title: 'Login Failed',
        text: error.message,
      });
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      const user = await signInWithGoogle();
      console.log('User signed in with Google:', user);
      setAuthState('logined');
      navigate('/main');
    } catch (error) {
      console.error('Google Sign-in error:', error.message);
      setError(error.message);
      Swal.fire({
        icon: 'error',
        title: 'Google Sign-in Failed',
        text: error.message,
      });
    }
  };

  const handleRegisterRedirect = () => {
    navigate('/register');
  };

  return (
    <div className="login-container">
      <div className="login-header">
        <img
          src="Material_2.png" // Replace with your image path
          alt="Logo"
          className="login-logo"
        />
        <h1 className="login-title">Communicate <span className="highlight">Expressly</span></h1>
      </div>
      <div className="login-form-container">
        <div className="login-tabs">
          <button className="tab-button active">Login</button>
          <button className="tab-button" onClick={handleRegisterRedirect}>
            Register
          </button>
        </div>
        {error && <p className="error-message">{error}</p>}
        <form className="login-form" onSubmit={(e) => e.preventDefault()}>
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            placeholder="Enter your Email"
            className="input-field"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            placeholder="Enter your Password"
            className="input-field"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <div className="form-footer">
            <button type="button" className="login-button" onClick={handleLogin}>
              Login
            </button>
            <a href="/forgot-password" className="forgot-password">
              Forget Password?
            </a>
          </div>
        </form>
        <div className="google-signin-container">
          <button className="google-signin-button" onClick={handleGoogleSignIn}>
            <img
              src="google-icon.svg" // Replace with Google icon path
              alt="Google Icon"
              className="google-icon"
            />
            Sign in with Google
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;