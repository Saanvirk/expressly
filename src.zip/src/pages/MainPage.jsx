import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/MainPage.css';
import { getDatabase, ref, onValue } from 'firebase/database';
import { auth } from '../config/firebase-auth';

// Function to fetch user data from Firebase Realtime Database
const fetchUserData = (userId, setUserData) => {
  const database = getDatabase();
  const userRef = ref(database, 'users/' + userId);
  onValue(userRef, (snapshot) => {
    const data = snapshot.val();
    setUserData(data);
  });
};

// Import the Google Maps script
const googleMapsScript = document.createElement('script');
googleMapsScript.src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyCAuAj7hfpeGuGbOhYvo1TU8lSSMHhv1Us&libraries=places";
googleMapsScript.async = true;
googleMapsScript.defer = true;
document.head.appendChild(googleMapsScript);

const MainPage = () => {
  const [currentView, setCurrentView] = useState('main');
  const [places, setPlaces] = useState([]);
  const [closestMatches, setClosestMatches] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [photo, setPhoto] = useState(null); // State to store the captured photo
  const navigate = useNavigate();
  const textInputRef = useRef(null);
  const videoRef = useRef(null); // Ref for the video element

  const switchToSettings = () => setCurrentView('settings');
  const switchToMain = () => setCurrentView('main');

  const [userData, setUserData] = useState(null);

  useEffect(() => {
    // Fetch user data from Firebase Realtime Database
    const userId = auth.currentUser?.uid;
    if (userId) {
      fetchUserData(userId, setUserData);
    } else {
      console.error('User is not authenticated.');
    }

    // Get user's location and fetch nearby places
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          fetchPlacesUsingSDK(latitude, longitude);
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    } else {
      console.error('Geolocation is not supported by this browser.');
    }

    // Perform AI word finding and embedding generation on component mount
    generateAIEmbeddings();

  }, []);

  // Navigation functions for different pages
  const goToCommunicationContext = () => {
    import('../components/MainFrame/communication-context.jsx').then(() => {
      navigate('/communication-context');
    });
  };
  const goToSupportResources = () => {
    import('../components/MainFrame/support-resources.jsx').then(() => {
      navigate('/support-resources');
    });
  };
  const goToAIContentFeedback = () => {
    import('../components/MainFrame/ai-content-feedback.jsx').then(() => {
      navigate('/ai-content-feedback');
    });
  };

  const fetchPlacesUsingSDK = (latitude, longitude) => {
    const location = new google.maps.LatLng(latitude, longitude);
    const request = {
      location,
      radius: 100, // Meters
      type: 'establishment',
    };

    const service = new google.maps.places.PlacesService(document.createElement('div'));
    service.nearbySearch(request, (results, status) => {
      if (status === google.maps.places.PlacesServiceStatus.OK) {
        setPlaces(results);
      } else {
        console.error('Error fetching places:', status);
      }
    });
  };

  const callLLM = async (fullPrompt) => {
    const apiUrl = 'https://www.jcapikey.com/v1/chat/completions';
    const apiKey = 'sk-KrJ8ttjJnAnBhLKtCc86719c13754cF3BdC2E4545b217d46'; // Replace with your actual API key
    const data = {
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: fullPrompt }],
      temperature: 0.7,
    };

    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) throw new Error('Error calling LLM API.');

      const result = await response.json();
      const responseMessage = result.choices[0].message.content;

      return responseMessage;
    } catch (err) {
      console.error('Error calling LLM:', err);
      throw err;
    }
  };

  const fetchClosestEmbeddings = async (text) => {
    try {
      const response = await fetch('http://localhost:4000/api/closest_embeddings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });

      if (!response.ok) throw new Error('Error fetching closest embeddings.');

      const data = await response.json();
      setClosestMatches(data.matches);
    } catch (err) {
      console.error('Error fetching embeddings:', err);
      setError('Failed to fetch closest embeddings.');
    }
  };

  const playTextToSpeech = async (text) => {
    try {
      const response = await fetch('http://localhost:4000/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });

      if (!response.ok) throw new Error('Error generating speech.');

      const arrayBuffer = await response.arrayBuffer();
      const blob = new Blob([arrayBuffer], { type: 'audio/mpeg' });
      const url = URL.createObjectURL(blob);

      const audio = new Audio(url);
      audio.play();
      audio.onended = () => URL.revokeObjectURL(url); // Clean up after playback
    } catch (err) {
      console.error('Error with TTS:', err);
      setError('Failed to play text-to-speech.');
    }
  };

  // Function to generate AI embeddings
  const generateAIEmbeddings = async () => {
    setIsLoading(true);
    setError(null);
    setClosestMatches([]); // Reset previous matches
    try {
      // Ensure userData and places are available
      if (!userData || places.length === 0) {
        setError('User data or location information is not available.');
        setIsLoading(false);
        return;
      }

      // Prepare the full prompt for the LLM
      const fullPrompt = `Given the following user data:
User Data:
${JSON.stringify(userData, null, 2)}
Current Time:
${new Date().toLocaleString()}
Nearby Places:
${JSON.stringify(
        places.slice(0, 5).map(place => ({ name: place.name, types: place.types })),
        null,
        2
      )}

Based on the above information, generate a few words that you think will be appropriate for the user to use in their AAC device.

**Instructions:**
- Choose the most suitable categories from the following list: [Adjective, Communication, DailyRoutine, Emotion, Food, Nouns, Places, Pronouns, Safety, Toys, Transition, Verbs].
- For each selected category, provide one or more words that fit the user's context.
- Format each entry as: \`Category_Word\`. For example: \`Pronouns_I\`, \`Verbs_Run\`.
- Do not include any additional text or explanations.

Please provide several such entries that are appropriate for the user's current context.

The user already inputted the following text:
${textInputRef.current?.value || ''}
`;

      // Call the LLM to generate the keywords
      console.log('Full Prompt:', fullPrompt);
      const keywords = await callLLM(fullPrompt);

      // Process the AI output
      const keywordList = keywords
        .split('\n')
        .map(line => line.trim())
        .filter(line => line);

      console.log('Keywords:', keywordList);

      // Fetch the closest embeddings using the first generated keyword
      if (keywordList.length > 0) {
        console.log('Fetching embeddings for:', keywordList[0]);
        await fetchClosestEmbeddings(keywordList[0]);
      }

    } catch (err) {
      console.error(err);
      setError('An error occurred during AI embedding generation.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleMicClick = async () => {
    const text = textInputRef.current?.value;
    if (text) {
      try {
        // Call LLM to organize the text into a meaningful sentence
        const organizedText = await callLLM(`Organize the following text into a meaningful sentence: "${text}"`);

        // Replace the text input with the organized sentence
        textInputRef.current.value = organizedText;

        // Play the organized sentence using TTS
        await playTextToSpeech(organizedText);
      } catch (err) {
        console.error('Error processing text with LLM:', err);
        setError('Failed to process text with LLM.');
      }
    } else {
      alert('Please enter some text.');
    }
  };

  // Function to handle button click that triggers AI embedding generation
  const handleGenerateEmbeddingsClick = () => {
    generateAIEmbeddings();
  };

  // Function to handle photo capture and upload
  const handleTakePhotoClick = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoRef.current.srcObject = stream;
      videoRef.current.play();

      // Capture the photo after a short delay to allow the video to start
      setTimeout(async () => {
        const canvas = document.createElement('canvas');
        canvas.width = videoRef.current.videoWidth;
        canvas.height = videoRef.current.videoHeight;
        const context = canvas.getContext('2d');
        context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const photoData = canvas.toDataURL('image/png');
        setPhoto(photoData);

        // Stop the video stream
        stream.getTracks().forEach(track => track.stop());

        // Upload the image and get the response from the LLM
        const response = await fetch('https://www.jcapikey.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer sk-KrJ8ttjJnAnBhLKtCc86719c13754cF3BdC2E4545b217d46`, // Replace with your actual API key
          },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: [
              {
                role: "user",
                content: [
                  {
                    type: "text", text: "What’s in this image? Instructions: Choose the most suitable categories from the following list: [Adjective, Communication, DailyRoutine, Emotion, Food, Nouns, Places, Pronouns, Safety, Toys, Transition, Verbs]. For each selected category, provide one or more words that fit the user's context. - Format each entry as: `Category_Word`. For example: `Pronouns_I`, `Verbs_Run`. - Do not include any additional text or explanations."
                  },
                  {
                    type: "image_url",
                    image_url: {
                      url: photoData,
                    },
                  },
                ],
              },
            ],
            max_tokens: 300,
          }),
        });

        if (!response.ok) throw new Error('Error calling LLM API.');

        const result = await response.json();
        console.log('LLM Response:', result.choices[0].message.content);

        const contextText = result.choices[0].message.content;
        await fetchClosestEmbeddings(contextText);

        // Clear the photo after getting the result
        setPhoto(null);
      }, 1000);
    } catch (err) {
      console.error('Error capturing photo:', err);
      setError('Failed to capture photo.');
    }
  };

  return (
    <div className="main-container">
      {/* Left Panel */}
      <div className="left-panel">
        {currentView === 'main' && (
          <>
            <button className="panel-button" onClick={switchToSettings}>
              Guardian
            </button>
            <button className="panel-button">AAC Mode</button>
          </>
        )}
        {currentView === 'settings' && (
          <button className="panel-button" onClick={switchToMain}>
            Back
          </button>
        )}
      </div>

      {/* Main View */}
      {currentView === 'main' && (
        <div className="center-panel">
          {/* Text Input and Buttons */}
          <div className="top-section">
            <input
              type="text"
              className="text-input"
              placeholder="Type something..."
              ref={textInputRef}
            />
            <div className="input-buttons">
              <button className="icon-button" onClick={handleMicClick}>
                <img src="mic_icon.png" alt="Voice" />
              </button>
              <button className="icon-button" onClick={handleTakePhotoClick}>
                <img src="camera_icon.png" alt="Camera" />
              </button>
            </div>
          </div>

          {/* Video Element for Camera Preview */}
          <video ref={videoRef} style={{ display: 'none' }}></video>

          {/* Display Captured Photo */}
          {photo && <img src={photo} alt="Captured" className="captured-photo" />}

          {/* Loading/Error Messages */}
          {isLoading && <p className="loading-text">Processing...</p>}
          {error && <p className="error-text">{error}</p>}

          {/* Button Grid */}
          <div className="button-grid">
            {closestMatches.length > 0
              ? closestMatches.slice(0, 5).map((match, index) => (
                <button
                  key={index}
                  className="communication_box"
                  onClick={() => {
                    handleGenerateEmbeddingsClick();
                    console.log('Clicked:', index);
                    const text = textInputRef.current?.value || '';
                    const match = closestMatches[index] || { meaning: 'default' };
                    console.log('Match:', match);
                    textInputRef.current.value = `${text} ${match.meaning.split('_')[1]}`.trim();
                  }}
                >
                  <img
                    src={`icons/${match.meaning}.svg`}
                    alt={match.meaning}
                    className="button-icon"
                  />
                  <div className="embedding-score">
                    {match.similarity.toFixed(2)}
                  </div>
                </button>
              ))
              : Array.from({ length: 5 }).map((_, index) => (
                <button
                  key={index}
                  className="communication_box"
                >
                  <img
                    src="icons/default.svg"
                    alt="Default"
                    className="button-icon"
                  />
                  <div className="embedding-score">-</div>
                </button>
              ))}
            {/* Regenerate Button */}
            <button className="communication_box" onClick={handleGenerateEmbeddingsClick}>
              <img src="refresh_icon.png" alt="Refresh" className="button-icon" />
            </button>
          </div>
        </div>
      )}

      {/* Settings View */}
      {currentView === 'settings' && (
        <div className="setting_container">
          <div className="profile-section">
            <img
              src="profile_pic.png"
              alt="Profile"
              className="profile-picture"
            />
            <div className="profile-details">
              <div className="profile-row">
                <span className="profile-label">Name</span>
                <span className="profile-value">{userData?.data?.childName || 'N/A'}</span>
              </div>
              <div className="profile-row">
                <span className="profile-label">Age</span>
                <span className="profile-value">{userData?.data?.childAge || 'N/A'}</span>
              </div>
              <div className="profile-row">
                <span className="profile-label">Gender</span>
                <span className="profile-value">{userData?.data?.childGender || 'N/A'}</span>
              </div>
              <div className="profile-row">
                <span className="profile-label">Diagnosis Details</span>
                <span className="profile-value">{userData?.data?.childDiagnosis || 'N/A'}</span>
              </div>
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="navigation-section">
            <button className="navigation-button" onClick={goToCommunicationContext}>
              Communication Context
            </button>
            <button className="navigation-button" onClick={goToSupportResources}>
              Support Resources
            </button>
            <button className="navigation-button" onClick={goToAIContentFeedback}>
              AI Content Feedback
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default MainPage;