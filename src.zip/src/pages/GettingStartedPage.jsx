import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db, ref, set } from '../config/firebase-auth';
import Step1 from '../components/GettingStarted/Step1';
import Step2 from '../components/GettingStarted/Step2';
import Step3 from '../components/GettingStarted/Step3';
import Step4 from '../components/GettingStarted/Step4';
import Step5 from '../components/GettingStarted/Step5';
import Step6 from '../components/GettingStarted/Step6';
import Step7 from '../components/GettingStarted/Step7';
import Step8 from '../components/GettingStarted/Step8';
import Step9 from '../components/GettingStarted/Step9';
import '../styles/GettingStarted.css';

const GettingStartedPage = ({ setAuthState }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({});
  const [userUID, setUserUID] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        setUserUID(user.uid);
      }
    });
  
    return () => unsubscribe();
  }, [navigate, userUID]);

  const nextStep = () => setCurrentStep((prevStep) => prevStep + 1);
  const previousStep = () => setCurrentStep((prevStep) => prevStep - 1);

  const handleSubmit = () => {
    if (!userUID) {
      console.error('User is not authenticated');
      return;
    }

    // Save formData to Firebase Realtime Database under the user's UID
    set(ref(db, `users/${userUID}/data`), formData)
      .then(() => {
        console.log('Data saved successfully!');
      })
      .catch((error) => {
        console.error('Error saving data:', error);
      });
  };

  return (
    <div className="getting-started-container">
      <div className="step-container">
        {currentStep === 1 && <Step1 nextStep={nextStep} />}
        {currentStep === 2 && (
          <Step2 nextStep={nextStep} previousStep={previousStep} />
        )}
        {currentStep === 3 && (
          <Step3
            nextStep={nextStep}
            previousStep={previousStep}
            formData={formData}
            setFormData={setFormData}
          />
        )}
        {currentStep === 4 && (
          <Step4
            nextStep={nextStep}
            previousStep={previousStep}
            formData={formData}
            setFormData={setFormData}
          />
        )}
        {currentStep === 5 && (
          <Step5 nextStep={nextStep} previousStep={previousStep} />
        )}
        {currentStep === 6 && (
          <Step6
            nextStep={nextStep}
            previousStep={previousStep}
            formData={formData}
            setFormData={setFormData}
            handleSubmit={handleSubmit}
          />
        )}
        {currentStep === 7 && <Step7 nextStep={nextStep} previousStep={previousStep} />}
        {currentStep === 8 && <Step8 nextStep={nextStep} formData={formData} previousStep={previousStep} handleSubmit={handleSubmit}/>}
        {currentStep === 9 && <Step9 setAuthState={setAuthState} />}
      </div>
    </div>
  );
};

export default GettingStartedPage;